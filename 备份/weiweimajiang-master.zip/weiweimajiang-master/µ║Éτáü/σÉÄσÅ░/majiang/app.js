

var gsh = require('./GameServer');
gsh.start();